from pathlib import Path
import base64
from concurrent.futures import ThreadPoolExecutor
import subprocess
import tempfile
from threading import Lock
from time import time
from uuid import uuid4

from fastapi import FastAPI, Header, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field

from .detector import analyze_video
from .models import AnalyzeRequest, AnalyzeResponse
from .planner import plan_crops, plan_podcast_layout
from service_v2.detector import analyze_identities
from service_v2.editorial import EditorialFrame, PROFILES, build_shot_plan
from service.silence import analyze_silences
from service.licensing import LicenseError, default_store
from service.offline_license import OfflineLicenseError
from service.hybrid_license import (
    activate_license,
    current_license_status,
    remove_license,
)

app = FastAPI(title="Gota Creator Kit Local Service", version="3.2.14")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["GET", "POST", "DELETE"],
    allow_headers=["*"],
)
license_store = default_store()

jobs: dict[str, dict] = {}
jobs_lock = Lock()
executor = ThreadPoolExecutor(max_workers=1)
JOB_TTL_SECONDS = 10 * 24 * 60 * 60
PREVIEW_TTL_SECONDS = 60 * 60
preview_items: dict[str, dict] = {}
preview_lock = Lock()
preview_cache_dir = Path(tempfile.gettempdir()) / "GotaCreatorKitPreview"


class AnalyzeV2Request(BaseModel):
    mediaPath: str = Field(min_length=1)
    sampleFps: float = Field(default=4.0, ge=1, le=12)
    profile: str = "podcast_dynamic"
    sensitivity: str = "balanced"
    peopleMode: str = "auto"
    framing: float = Field(default=1.2, ge=0.85, le=1.6)
    rules: dict = Field(default_factory=dict)
    startSeconds: float = Field(default=0, ge=0)
    endSeconds: float | None = Field(default=None, gt=0)


class SilenceRequest(BaseModel):
    mediaPath: str = Field(min_length=1)
    thresholdDb: float = Field(default=-42, ge=-96, le=0)
    minimumSilenceSeconds: float = Field(default=0.4, ge=0.1, le=5)
    paddingSeconds: float = Field(default=0.12, ge=0, le=1)
    startSeconds: float = Field(default=0, ge=0)
    endSeconds: float = Field(gt=0)


class AccountRequest(BaseModel):
    email: str = Field(min_length=3, max_length=254)
    password: str = Field(min_length=8, max_length=200)
    deviceId: str = Field(min_length=8, max_length=200)
    deviceName: str = Field(default="Equipo", max_length=80)


class GiftRedeemRequest(BaseModel):
    code: str = Field(min_length=3, max_length=100)


class OfflineLicenseRequest(BaseModel):
    code: str = Field(min_length=4, max_length=4096)
    deviceId: str = Field(min_length=8, max_length=200)


class OfflineLicenseStatusRequest(BaseModel):
    deviceId: str = Field(min_length=8, max_length=200)


class PreviewRegistrationRequest(BaseModel):
    mediaPath: str = Field(min_length=1, max_length=4096)


def bearer_token(authorization: str | None) -> str:
    if not authorization or not authorization.lower().startswith("bearer "):
        raise HTTPException(status_code=401, detail="Inicia sesion para continuar.")
    return authorization[7:].strip()


def license_call(callback):
    try:
        return callback()
    except LicenseError as error:
        raise HTTPException(status_code=400, detail=str(error)) from error


def offline_license_call(callback):
    try:
        return callback()
    except OfflineLicenseError as error:
        raise HTTPException(status_code=400, detail=str(error)) from error


def cleanup_expired_jobs():
    cutoff = time() - JOB_TTL_SECONDS
    with jobs_lock:
        expired = [
            job_id for job_id, job in jobs.items()
            if job.get("createdAt", 0) < cutoff
        ]
        for job_id in expired:
            del jobs[job_id]


def cleanup_expired_previews():
    cutoff = time() - PREVIEW_TTL_SECONDS
    with preview_lock:
        expired = [
            token for token, item in preview_items.items()
            if item.get("createdAt", 0) < cutoff
        ]
        for token in expired:
            item = preview_items.pop(token)
            generated = item.get("path")
            if generated:
                try:
                    Path(generated).unlink(missing_ok=True)
                except OSError:
                    # Un reproductor todavía podría estar cerrando el archivo.
                    pass


def make_uxp_preview(source: Path, token: str) -> tuple[Path, str]:
    """Convierte medios a códecs que el reproductor UXP de Premiere soporta.

    No modifica el archivo original. La copia de vista previa se guarda solo en
    temporal y se elimina automáticamente una hora después.
    """
    try:
        import imageio_ffmpeg
    except ImportError as error:
        raise RuntimeError("Falta el componente de vista previa. Reinstala Gota Creator Kit.") from error
    preview_cache_dir.mkdir(parents=True, exist_ok=True)
    audio_extensions = {".mp3", ".wav", ".m4a", ".aac", ".aif", ".aiff", ".ogg", ".flac"}
    is_audio = source.suffix.lower() in audio_extensions
    target = preview_cache_dir / f"{token}{'.mp3' if is_audio else '.mp4'}"
    if is_audio:
        command = [
            imageio_ffmpeg.get_ffmpeg_exe(), "-y", "-hide_banner", "-loglevel", "error",
            "-i", str(source), "-vn", "-c:a", "libmp3lame", "-q:a", "4", str(target),
        ]
        media_type = "audio/mpeg"
    else:
        command = [
            imageio_ffmpeg.get_ffmpeg_exe(), "-y", "-hide_banner", "-loglevel", "error",
            "-i", str(source), "-map", "0:v:0", "-map", "0:a?",
            "-vf", "scale='min(960,iw)':-2:force_original_aspect_ratio=decrease",
            "-c:v", "libx264", "-preset", "ultrafast", "-crf", "28",
            "-c:a", "aac", "-b:a", "128k", "-movflags", "+faststart", str(target),
        ]
        media_type = "video/mp4"
    completed = subprocess.run(
        command,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.PIPE,
        creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
        check=False,
    )
    if completed.returncode != 0 or not target.is_file():
        message = completed.stderr.decode("utf-8", errors="replace").strip()
        raise RuntimeError(message or "No se pudo convertir el archivo para la vista previa.")
    return target, media_type


def build_result(request: AnalyzeRequest, progress_callback=None):
    path = Path(request.mediaPath)
    if not path.is_file():
        raise ValueError("El medio local no existe")
    width, height, duration, detections, frames, scene_cuts = analyze_video(
        path,
        request.sampleFps,
        request.startSeconds,
        request.endSeconds,
        progress_callback,
    )
    keyframes = plan_crops(
        detections,
        width / height,
        request.targetAspect,
        request.margin,
        request.smoothing,
    )
    layout_frames = plan_podcast_layout(
        frames, width / height, request.margin, request.smoothing
    )
    single_frames = sum(item["mode"] == "single" for item in layout_frames)
    split_frames = sum(item["mode"] == "split" for item in layout_frames)
    warnings = []
    if not keyframes:
        warnings.append("No se detectaron caras; no se genero un encuadre.")
    mean_confidence = (
        sum(item["confidence"] for item in keyframes) / len(keyframes)
        if keyframes else 0
    )
    return AnalyzeResponse(
        sourceWidth=width,
        sourceHeight=height,
        durationSeconds=duration,
        meanConfidence=mean_confidence,
        warnings=warnings,
        keyframes=keyframes,
        layoutFrames=layout_frames,
        singleFrames=single_frames,
        splitFrames=split_frames,
        sceneCuts=scene_cuts,
        sceneCutCount=len(scene_cuts),
    )


def run_job(job_id: str, request: AnalyzeRequest):
    def update_progress(value: float):
        with jobs_lock:
            jobs[job_id]["progress"] = round(value * 100)
            jobs[job_id]["status"] = "running"

    try:
        result = build_result(request, update_progress)
        with jobs_lock:
            jobs[job_id].update({
                "status": "completed",
                "progress": 100,
                "result": result.model_dump(),
            })
    except Exception as error:
        with jobs_lock:
            jobs[job_id].update({
                "status": "failed",
                "error": str(error),
            })


def build_v2_result(request: AnalyzeV2Request, progress_callback=None):
    path = Path(request.mediaPath)
    if not path.is_file():
        raise ValueError("El medio local no existe")
    model_path = Path(__file__).resolve().parents[2] / "models" / (
        "face_detection_yunet_2023mar.onnx"
    )
    identity_frames = analyze_identities(
        path,
        model_path,
        sample_fps=request.sampleFps,
        start_seconds=request.startSeconds,
        end_seconds=request.endSeconds,
        progress_callback=progress_callback,
        sensitivity=request.sensitivity,
    )
    import cv2
    capture = cv2.VideoCapture(str(path))
    source_width = int(capture.get(cv2.CAP_PROP_FRAME_WIDTH))
    source_height = int(capture.get(cv2.CAP_PROP_FRAME_HEIGHT))
    duration = (
        capture.get(cv2.CAP_PROP_FRAME_COUNT) /
        (capture.get(cv2.CAP_PROP_FPS) or 30.0)
    )
    capture.release()
    editorial_frames = []
    keyframes = []
    layout_frames = []
    for frame in identity_frames:
        subjects = frame["subjects"]
        active_mouths = sum(
            subject["mouthActivity"] >= 0.018 for subject in subjects
        )
        confidence = (
            sum(subject["confidence"] for subject in subjects) / len(subjects)
            if subjects else 0.0
        )
        editorial_frames.append(EditorialFrame(
            time=frame["timeSeconds"],
            speaker_id=frame["speakerId"],
            subject_ids=tuple(subject["id"] for subject in subjects),
            confidence=confidence,
            overlap=len(subjects) >= 2 and active_mouths >= 2,
        ))
        ordered = sorted(subjects, key=lambda item: item["x"])
        layout_subjects = []
        is_two_person_view = len(ordered) >= 2
        for subject in ordered[:2]:
            # El plano doble necesita bastante más aire que un punch-in:
            # cada rostro ocupa aproximadamente 35-45% del ancho de su mitad.
            width_factor = 3.6 if is_two_person_view else 2.0
            height_factor = 4.0 if is_two_person_view else 2.5
            crop_width = min(
                1.0, subject["width"] * width_factor * request.framing
            )
            crop_height = min(
                1.0, subject["height"] * height_factor * request.framing
            )
            center_x = subject["x"] + subject["width"] / 2
            # Coloca los ojos sobre el tercio superior y conserva hombros.
            center_y = subject["y"] + subject["height"] * (
                1.0 if is_two_person_view else 0.95
            )
            center_x = min(1 - crop_width / 2, max(crop_width / 2, center_x))
            center_y = min(1 - crop_height / 2, max(crop_height / 2, center_y))
            layout_subjects.append({
                "centerX": center_x,
                "centerY": center_y,
                "width": crop_width,
                "height": crop_height,
                "confidence": subject["confidence"],
                "subjectId": subject["id"],
            })
        use_split = (
            len(layout_subjects) >= 2 and request.peopleMode != "single"
        )
        layout_frames.append({
            "timeSeconds": frame["timeSeconds"],
            "mode": "split" if use_split else "single",
            "speakerId": frame["speakerId"],
            "subjects": layout_subjects,
        })
        chosen = next(
            (subject for subject in subjects
             if subject["id"] == frame["speakerId"]),
            max(subjects, key=lambda item: item["confidence"])
            if subjects else None,
        )
        if chosen:
            crop_width = min(
                1.0, chosen["width"] * 2.0 * request.framing
            )
            crop_height = min(
                1.0, chosen["height"] * 2.5 * request.framing
            )
            center_x = chosen["x"] + chosen["width"] / 2
            center_y = chosen["y"] + chosen["height"] * 0.95
            center_x = min(1 - crop_width / 2, max(crop_width / 2, center_x))
            center_y = min(1 - crop_height / 2, max(crop_height / 2, center_y))
            keyframes.append({
                "timeSeconds": frame["timeSeconds"],
                "centerX": center_x,
                "centerY": center_y,
                "width": crop_width,
                "height": crop_height,
                "confidence": chosen["confidence"],
                "mouthActivity": chosen["mouthActivity"],
                "subjectId": chosen["id"],
            })
    shots, warnings = build_shot_plan(
        editorial_frames, request.profile, request.rules
    )
    preview_capture = cv2.VideoCapture(str(path))
    for shot in shots[:30]:
        midpoint = (shot["startSeconds"] + shot["endSeconds"]) / 2
        preview_capture.set(cv2.CAP_PROP_POS_MSEC, midpoint * 1000)
        ok, preview_frame = preview_capture.read()
        if not ok:
            continue
        preview_height, preview_width = preview_frame.shape[:2]
        preview_scale = min(1.0, 240 / max(1, preview_width))
        preview_frame = cv2.resize(
            preview_frame,
            (
                max(1, round(preview_width * preview_scale)),
                max(1, round(preview_height * preview_scale)),
            ),
            interpolation=cv2.INTER_AREA,
        )
        encoded, jpeg = cv2.imencode(
            ".jpg", preview_frame, [cv2.IMWRITE_JPEG_QUALITY, 68]
        )
        if encoded:
            shot["previewDataUrl"] = (
                "data:image/jpeg;base64," +
                base64.b64encode(jpeg.tobytes()).decode("ascii")
            )
    preview_capture.release()
    editorial_cuts = [
        round(shot["startSeconds"], 4)
        for shot in shots[1:]
    ]
    if not keyframes:
        warnings.append({
            "type": "no_faces",
            "timeSeconds": request.startSeconds,
            "message": "No se confirmaron rostros reales.",
        })
    if request.peopleMode == "split" and not any(
        frame["mode"] == "split" for frame in layout_frames
    ):
        warnings.append({
            "type": "missing_second_person",
            "timeSeconds": request.startSeconds,
            "message": "Se pidieron dos personas, pero no se confirmó la segunda.",
        })
    mean_confidence = (
        sum(frame["confidence"] for frame in keyframes) / len(keyframes)
        if keyframes else 0.0
    )
    return {
        "version": "3.2.14",
        "profile": request.profile,
        "sourceWidth": source_width,
        "sourceHeight": source_height,
        "durationSeconds": duration,
        "meanConfidence": mean_confidence,
        "keyframes": keyframes,
        "layoutFrames": layout_frames,
        "singleFrames": sum(
            frame["mode"] == "single" for frame in layout_frames
        ),
        "splitFrames": sum(
            frame["mode"] == "split" for frame in layout_frames
        ),
        "sceneCuts": editorial_cuts,
        "sceneCutCount": len(editorial_cuts),
        "frames": identity_frames,
        "shots": shots,
        "warnings": warnings,
        "summary": {
            "samples": len(identity_frames),
            "shots": len(shots),
            "subjects": sorted({
                subject["id"]
                for frame in identity_frames
                for subject in frame["subjects"]
            }),
        },
    }


def run_v2_job(job_id: str, request: AnalyzeV2Request):
    def update_progress(value: float):
        with jobs_lock:
            if jobs.get(job_id, {}).get("cancelRequested"):
                raise RuntimeError("Analisis cancelado por el usuario")
            jobs[job_id]["progress"] = round(value * 100)
            jobs[job_id]["status"] = "running"

    try:
        result = build_v2_result(request, update_progress)
        with jobs_lock:
            if jobs[job_id].get("cancelRequested"):
                jobs[job_id].update({
                    "status": "canceled",
                    "error": "Analisis cancelado por el usuario",
                })
                return
            jobs[job_id].update({
                "status": "completed",
                "progress": 100,
                "result": result,
            })
    except Exception as error:
        with jobs_lock:
            if job_id not in jobs:
                return
            canceled = jobs[job_id].get("cancelRequested", False)
            jobs[job_id].update({
                "status": "canceled" if canceled else "failed",
                "error": str(error),
            })


def run_silence_job(job_id: str, request: SilenceRequest):
    def update_progress(value: float):
        with jobs_lock:
            if jobs.get(job_id, {}).get("cancelRequested"):
                raise RuntimeError("Análisis cancelado por el usuario")
            jobs[job_id]["progress"] = round(value * 100)
            jobs[job_id]["status"] = "running"

    try:
        path = Path(request.mediaPath)
        if not path.is_file():
            raise ValueError("El medio local no existe")
        result = analyze_silences(
            path,
            request.startSeconds,
            request.endSeconds,
            request.thresholdDb,
            request.minimumSilenceSeconds,
            request.paddingSeconds,
            update_progress,
        )
        with jobs_lock:
            jobs[job_id].update({
                "status": "completed",
                "progress": 100,
                "result": result,
            })
    except Exception as error:
        with jobs_lock:
            if job_id not in jobs:
                return
            canceled = jobs[job_id].get("cancelRequested", False)
            jobs[job_id].update({
                "status": "canceled" if canceled else "failed",
                "error": str(error),
            })


@app.get("/health")
def health():
    return {"status": "ok", "version": "3.2.14"}


@app.post("/v1/preview/register")
def register_preview(request: PreviewRegistrationRequest):
    """Autoriza temporalmente un recurso elegido en Biblioteca Gota.

    UXP no deja a los elementos HTML de vídeo/audio reproducir de forma fiable
    rutas `file:` del disco. El panel registra explícitamente la entrada que el
    usuario ya eligió y recibe una URL local de corta vida; no se enumeran ni se
    exponen carpetas del equipo.
    """
    path = Path(request.mediaPath).expanduser().resolve()
    if not path.is_file():
        raise HTTPException(status_code=404, detail="El archivo de vista previa ya no existe.")
    allowed_extensions = {
        ".mp4", ".mov", ".m4v", ".webm", ".avi", ".mkv",
        ".mp3", ".wav", ".m4a", ".aac", ".aif", ".aiff", ".ogg", ".flac",
        ".png", ".jpg", ".jpeg", ".gif", ".webp", ".bmp",
    }
    if path.suffix.lower() not in allowed_extensions:
        raise HTTPException(status_code=415, detail="Este formato no admite vista previa interna.")
    cleanup_expired_previews()
    token = uuid4().hex
    try:
        preview_path, media_type = make_uxp_preview(path, token)
    except RuntimeError as error:
        raise HTTPException(status_code=422, detail=f"No se pudo preparar la vista previa: {error}") from error
    with preview_lock:
        preview_items[token] = {
            "path": preview_path,
            "mediaType": media_type,
            "createdAt": time(),
        }
    return {"token": token, "url": f"/v1/preview/{token}"}


@app.get("/v1/preview/{token}")
def get_preview(token: str):
    cleanup_expired_previews()
    with preview_lock:
        item = preview_items.get(token)
    if not item:
        raise HTTPException(status_code=404, detail="La vista previa venció. Selecciona el archivo otra vez.")
    path = Path(item["path"])
    if not path.is_file():
        raise HTTPException(status_code=404, detail="El archivo de vista previa ya no existe.")
    return FileResponse(path, media_type=item.get("mediaType"))


@app.post("/v3/account/register")
def register_account(request: AccountRequest):
    token, account = license_call(
        lambda: license_store.register(
            request.email, request.password, request.deviceId, request.deviceName
        )
    )
    return {"token": token, "account": account}


@app.post("/v3/account/login")
def login_account(request: AccountRequest):
    token, account = license_call(
        lambda: license_store.login(
            request.email, request.password, request.deviceId, request.deviceName
        )
    )
    return {"token": token, "account": account}


@app.get("/v3/license/status")
def license_status(authorization: str | None = Header(default=None)):
    token = bearer_token(authorization)
    return license_call(lambda: license_store.status(token))


@app.post("/v3/gifts/redeem")
def redeem_gift(
    request: GiftRedeemRequest,
    authorization: str | None = Header(default=None),
):
    token = bearer_token(authorization)
    return license_call(lambda: license_store.redeem(token, request.code))


@app.post("/v3/account/logout", status_code=204)
def logout_account(authorization: str | None = Header(default=None)):
    token = bearer_token(authorization)
    license_store.logout(token)


@app.post("/v3/billing/checkout")
def test_checkout(authorization: str | None = Header(default=None)):
    bearer_token(authorization)
    return {
        "testMode": True,
        "configured": False,
        "monthlyPriceUsd": 3,
        "annualPriceUsd": 30,
        "message": (
            "El pago esta en modo de prueba. Falta conectar la cuenta comercial "
            "de Stripe antes de aceptar cargos."
        ),
    }


@app.post("/v4/license/activate")
def activate_offline_license(request: OfflineLicenseRequest):
    return offline_license_call(
        lambda: activate_license(request.code, request.deviceId)
    )


@app.post("/v4/license/status")
def offline_license_status(request: OfflineLicenseStatusRequest):
    return offline_license_call(
        lambda: current_license_status(request.deviceId)
    )


@app.delete("/v4/license", status_code=204)
def deactivate_offline_license(device_id: str | None = None):
    remove_license(device_id)


@app.get("/v2/profiles")
def get_v2_profiles():
    return PROFILES


@app.post("/v2/jobs", status_code=202)
def create_v2_job(request: AnalyzeV2Request):
    cleanup_expired_jobs()
    job_id = str(uuid4())
    with jobs_lock:
        jobs[job_id] = {
            "status": "queued",
            "progress": 0,
            "createdAt": time(),
            "engine": "2.0",
        }
    executor.submit(run_v2_job, job_id, request)
    return {"jobId": job_id, "status": "queued", "progress": 0}


@app.post("/v3/silence-jobs", status_code=202)
def create_silence_job(request: SilenceRequest):
    cleanup_expired_jobs()
    job_id = str(uuid4())
    with jobs_lock:
        jobs[job_id] = {
            "status": "queued",
            "progress": 0,
            "createdAt": time(),
            "engine": "silence-1.0",
        }
    executor.submit(run_silence_job, job_id, request)
    return {"jobId": job_id, "status": "queued", "progress": 0}


@app.post("/v1/analyze", response_model=AnalyzeResponse)
def analyze(request: AnalyzeRequest):
    try:
        return build_result(request)
    except ValueError as error:
        raise HTTPException(status_code=422, detail=str(error)) from error


@app.post("/v1/jobs", status_code=202)
def create_job(request: AnalyzeRequest):
    cleanup_expired_jobs()
    job_id = str(uuid4())
    with jobs_lock:
        jobs[job_id] = {
            "status": "queued",
            "progress": 0,
            "createdAt": time(),
        }
    executor.submit(run_job, job_id, request)
    return {"jobId": job_id, "status": "queued", "progress": 0}


@app.get("/v1/jobs/{job_id}")
def get_job(job_id: str):
    cleanup_expired_jobs()
    with jobs_lock:
        job = jobs.get(job_id)
        if not job:
            raise HTTPException(status_code=404, detail="Trabajo no encontrado")
        return dict(job)


@app.delete("/v1/jobs/{job_id}", status_code=204)
def delete_job(job_id: str):
    with jobs_lock:
        job = jobs.get(job_id)
        if not job:
            return
        if job.get("status") in {"queued", "running"}:
            job["cancelRequested"] = True
            job["status"] = "canceling"
        else:
            jobs.pop(job_id, None)
