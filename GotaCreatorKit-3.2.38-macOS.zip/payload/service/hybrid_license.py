"""Licencias remotas con respaldo temporal sin conexion y compatibilidad GCK1."""

from __future__ import annotations

from datetime import datetime, timezone
import json
import os
from pathlib import Path
import subprocess
import sys
import time
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

from service.offline_license import (
    OfflineLicenseError,
    activate_code as activate_signed_code,
    current_status as signed_status,
    remove_license as remove_signed_license,
)


CLOUD_CONFIG_FILE = Path(__file__).with_name("license-cloud.json")
CLOUD_STATE_FILE = Path(__file__).with_name("gota-cloud-license.json")
DEFAULT_API_URL = "https://bygota-creatorkit.djm4pf2v57.workers.dev"
DEFAULT_OFFLINE_TOLERANCE_HOURS = 72


def _api_url() -> str:
    value = os.environ.get("GCK_LICENSE_API_URL", "").strip()
    if value:
        return value.rstrip("/")
    if CLOUD_CONFIG_FILE.is_file():
        try:
            config = json.loads(CLOUD_CONFIG_FILE.read_text(encoding="utf-8"))
            configured = str(config.get("apiUrl") or "").strip().rstrip("/")
            return configured or DEFAULT_API_URL
        except (OSError, ValueError, json.JSONDecodeError):
            return DEFAULT_API_URL
    return DEFAULT_API_URL


def _cloud_call(path: str, body: dict) -> dict | None:
    base_url = _api_url()
    if not base_url:
        raise OfflineLicenseError(
            "El servicio de licencias en linea aun no esta configurado."
        )
    request = Request(
        f"{base_url}{path}",
        data=json.dumps(body).encode("utf-8"),
        headers={
            "content-type": "application/json",
            "accept": "application/json",
            "user-agent": "GotaCreatorKit/3.2",
        },
        method="POST",
    )
    try:
        with urlopen(request, timeout=8) as response:
            if response.status == 204:
                return None
            return json.loads(response.read().decode("utf-8"))
    except HTTPError as error:
        try:
            payload = json.loads(error.read().decode("utf-8"))
            message = str(payload.get("detail") or f"Error {error.code}")
        except Exception:
            message = f"Error {error.code} al validar la licencia."
        raise OfflineLicenseError(message) from error
    except (URLError, TimeoutError, OSError) as error:
        # En algunos macOS recientes Python queda sin acceso al almacén de
        # certificados del sistema después de una instalación local. curl sí
        # usa dicho almacén, por lo que lo usamos como respaldo seguro.
        if sys.platform == "darwin":
            return _macos_cloud_call(base_url, path, body, error)
        raise OfflineLicenseError(
            "No se pudo conectar al servidor de licencias."
        ) from error


def _macos_cloud_call(base_url: str, path: str, body: dict, original_error: Exception) -> dict | None:
    curl = "/usr/bin/curl"
    if not Path(curl).is_file():
        raise OfflineLicenseError("No se pudo conectar al servidor de licencias.") from original_error
    try:
        completed = subprocess.run(
            [
                curl, "--silent", "--show-error", "--fail-with-body",
                "--connect-timeout", "8", "--max-time", "15",
                "-X", "POST", f"{base_url}{path}",
                "-H", "content-type: application/json",
                "-H", "accept: application/json",
                "-H", "user-agent: GotaCreatorKit/3.2",
                "--data-binary", json.dumps(body),
            ],
            capture_output=True, text=True, check=False,
        )
    except OSError as error:
        raise OfflineLicenseError("No se pudo conectar al servidor de licencias.") from error
    text = completed.stdout.strip()
    if completed.returncode == 0:
        if not text:
            return None
        try:
            return json.loads(text)
        except json.JSONDecodeError as error:
            raise OfflineLicenseError("El servidor devolvio una respuesta invalida.") from error
    try:
        payload = json.loads(text)
        message = str(payload.get("detail") or "No se pudo validar la licencia.")
    except (TypeError, ValueError, json.JSONDecodeError):
        message = "No se pudo conectar al servidor de licencias."
    raise OfflineLicenseError(message)


def _public(result: dict) -> dict:
    output = dict(result)
    output.pop("activationToken", None)
    return output


def _save_cloud_state(result: dict, device_id: str):
    state = {
        "deviceId": device_id,
        "activationToken": result["activationToken"],
        "license": _public(result),
        "checkedAt": int(time.time()),
    }
    CLOUD_STATE_FILE.write_text(
        json.dumps(state, indent=2), encoding="utf-8"
    )


def _load_cloud_state(device_id: str) -> dict | None:
    if not CLOUD_STATE_FILE.is_file():
        return None
    try:
        state = json.loads(CLOUD_STATE_FILE.read_text(encoding="utf-8"))
        if state.get("deviceId") != device_id:
            return None
        if not state.get("activationToken"):
            return None
        return state
    except (OSError, ValueError, json.JSONDecodeError):
        return None


def _cached_status(state: dict) -> dict:
    license_data = dict(state.get("license") or {})
    tolerance = int(
        license_data.get("offlineToleranceHours")
        or DEFAULT_OFFLINE_TOLERANCE_HOURS
    )
    elapsed = int(time.time()) - int(state.get("checkedAt") or 0)
    if elapsed > tolerance * 3600:
        raise OfflineLicenseError(
            "Conectate a internet para volver a comprobar esta licencia."
        )
    expires_at = license_data.get("expiresAt")
    if expires_at and not license_data.get("perpetual"):
        try:
            expiry = datetime.fromisoformat(
                str(expires_at).replace("Z", "+00:00")
            )
        except ValueError as error:
            raise OfflineLicenseError(
                "La licencia guardada tiene una fecha invalida."
            ) from error
        now = datetime.now(timezone.utc)
        remaining_seconds = (expiry - now).total_seconds()
        if remaining_seconds <= 0:
            raise OfflineLicenseError("Esta licencia ya vencio.")
        license_data["daysRemaining"] = int(
            (remaining_seconds + 86399) // 86400
        )
    license_data["active"] = True
    license_data["offline"] = True
    return license_data


def activate_license(code: str, device_id: str) -> dict:
    normalized = code.strip()
    if "GCK1." in normalized:
        return activate_signed_code(normalized, device_id)
    result = _cloud_call(
        "/v1/licenses/activate",
        {"code": normalized, "deviceId": device_id, "deviceName": "Premiere"},
    )
    if not result or not result.get("activationToken"):
        raise OfflineLicenseError("El servidor no devolvio una activacion valida.")
    _save_cloud_state(result, device_id)
    return _public(result)


def current_license_status(device_id: str) -> dict:
    state = _load_cloud_state(device_id)
    if state:
        try:
            result = _cloud_call(
                "/v1/licenses/status",
                {
                    "deviceId": device_id,
                    "activationToken": state["activationToken"],
                },
            )
            if not result:
                raise OfflineLicenseError("Respuesta de licencia vacia.")
            result["activationToken"] = state["activationToken"]
            _save_cloud_state(result, device_id)
            return _public(result)
        except OfflineLicenseError as error:
            if "No se pudo conectar" not in str(error):
                raise
            return _cached_status(state)
    return signed_status(device_id)


def remove_license(device_id: str | None = None):
    if device_id:
        state = _load_cloud_state(device_id)
        if state:
            try:
                _cloud_call(
                    "/v1/licenses/deactivate",
                    {
                        "deviceId": device_id,
                        "activationToken": state["activationToken"],
                    },
                )
            except OfflineLicenseError:
                pass
    CLOUD_STATE_FILE.unlink(missing_ok=True)
    remove_signed_license()
