from pathlib import Path
import os
import sys
import traceback

import uvicorn


PID_FILE = Path(__file__).with_name("autoframe.pid")
LOG_FILE = Path(__file__).with_name("autoframe-service.log")
PROJECT_ROOT = Path(__file__).resolve().parent.parent


def main():
    os.chdir(PROJECT_ROOT)
    project_root_text = str(PROJECT_ROOT)
    if project_root_text not in sys.path:
        sys.path.insert(0, project_root_text)
    PID_FILE.write_text(str(os.getpid()), encoding="ascii")
    try:
        with LOG_FILE.open("w", encoding="utf-8") as log:
            sys.stdout = log
            sys.stderr = log
            log.write("Iniciando Gota Creator Kit...\n")
            log.flush()
            try:
                uvicorn.run(
                    "service.app.main:app",
                    host="127.0.0.1",
                    port=8765,
                    log_level="warning",
                    log_config=None,
                    access_log=False,
                )
            except Exception:
                traceback.print_exc(file=log)
                raise
    finally:
        try:
            PID_FILE.unlink(missing_ok=True)
        except OSError:
            pass


if __name__ == "__main__":
    main()
