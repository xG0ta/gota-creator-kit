import unittest

from service.silence import intervals_from_levels, invert_intervals


class SilenceTests(unittest.TestCase):
    def test_threshold_and_padding_create_safe_cut(self):
        levels = [-20] * 5 + [-60] * 10 + [-20] * 5
        result = intervals_from_levels(
            levels, -42, 10, 0.1, 0.6, 0.2
        )
        self.assertEqual(len(result), 1)
        self.assertAlmostEqual(result[0]["startSeconds"], 10.7)
        self.assertAlmostEqual(result[0]["endSeconds"], 11.3)

    def test_short_pause_is_preserved(self):
        result = intervals_from_levels(
            [-20, -60, -60, -20], -42, 0, 0.1, 0.4, 0
        )
        self.assertEqual(result, [])

    def test_kept_segments_are_inverse(self):
        result = invert_intervals(
            [{"startSeconds": 2, "endSeconds": 3}], 1, 5
        )
        self.assertEqual(
            result,
            [
                {"startSeconds": 1, "endSeconds": 2, "durationSeconds": 1},
                {"startSeconds": 3, "endSeconds": 5, "durationSeconds": 2},
            ],
        )


if __name__ == "__main__":
    unittest.main()
