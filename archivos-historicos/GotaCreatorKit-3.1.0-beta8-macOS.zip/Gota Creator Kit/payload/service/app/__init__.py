"""AutoFrame local service."""
