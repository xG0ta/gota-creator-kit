#!/bin/bash

INSTALL_DIR="$HOME/Library/Application Support/GotaCreatorKit"
PYTHON_BIN="$INSTALL_DIR/venv/bin/python"
SERVICE_SCRIPT="$INSTALL_DIR/service/run_service.py"
SERVICE_PID=""

stop_service() {
  if [ -n "$SERVICE_PID" ] && kill -0 "$SERVICE_PID" 2>/dev/null; then
    kill "$SERVICE_PID" 2>/dev/null || true
    wait "$SERVICE_PID" 2>/dev/null || true
  fi
  SERVICE_PID=""
}

trap stop_service EXIT INT TERM

while true; do
  if pgrep -f "/Applications/Adobe Premiere Pro.*Adobe Premiere Pro" >/dev/null 2>&1; then
    if [ -z "$SERVICE_PID" ] || ! kill -0 "$SERVICE_PID" 2>/dev/null; then
      cd "$INSTALL_DIR" || exit 1
      "$PYTHON_BIN" "$SERVICE_SCRIPT" &
      SERVICE_PID=$!
    fi
  else
    stop_service
  fi
  sleep 2
done
