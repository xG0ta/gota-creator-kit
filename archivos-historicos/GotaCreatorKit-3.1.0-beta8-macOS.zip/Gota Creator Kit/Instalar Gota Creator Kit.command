#!/bin/bash
set -euo pipefail

PRODUCT_NAME="Gota Creator Kit"
INSTALL_DIR="$HOME/Library/Application Support/GotaCreatorKit"
PAYLOAD_DIR="$(cd "$(dirname "$0")/payload" && pwd)"
LOG_FILE="$INSTALL_DIR/installer.log"
PYTHON_BIN=""

mkdir -p "$INSTALL_DIR"
exec > >(tee "$LOG_FILE") 2>&1
echo "Instalando $PRODUCT_NAME..."

find_python() {
  for candidate in \
    "/Library/Frameworks/Python.framework/Versions/3.12/bin/python3" \
    "/opt/homebrew/bin/python3" \
    "/usr/local/bin/python3" \
    "$(command -v python3 2>/dev/null || true)"; do
    if [ -n "$candidate" ] && [ -x "$candidate" ]; then
      if "$candidate" -c 'import sys; raise SystemExit(sys.version_info < (3, 10))'; then
        PYTHON_BIN="$candidate"
        return 0
      fi
    fi
  done
  return 1
}

if ! find_python; then
  PYTHON_PKG="$TMPDIR/python-3.12.10-macos11.pkg"
  echo "Python 3.12 es necesario. Se descargará el instalador universal oficial."
  curl -L --fail \
    "https://www.python.org/ftp/python/3.12.10/python-3.12.10-macos11.pkg" \
    -o "$PYTHON_PKG"
  echo "macOS solicitará tu contraseña para instalar Python."
  sudo /usr/sbin/installer -pkg "$PYTHON_PKG" -target /
  rm -f "$PYTHON_PKG"
  find_python
fi

pkill -f "$INSTALL_DIR/service/run_service.py" 2>/dev/null || true
launchctl bootout "gui/$UID/com.xg0ta.gotacreatorkit" 2>/dev/null || true

ditto "$PAYLOAD_DIR/service" "$INSTALL_DIR/service"
ditto "$PAYLOAD_DIR/service_v2" "$INSTALL_DIR/service_v2"
cp "$PAYLOAD_DIR/Supervisor.sh" "$INSTALL_DIR/Supervisor.sh"
cp "$PAYLOAD_DIR/Gota Creator Kit.ccx" "$INSTALL_DIR/Gota Creator Kit.ccx"
chmod +x "$INSTALL_DIR/Supervisor.sh"

"$PYTHON_BIN" -m venv "$INSTALL_DIR/venv"
"$INSTALL_DIR/venv/bin/python" -m pip install \
  --disable-pip-version-check \
  -r "$INSTALL_DIR/service/requirements-installer.txt"

mkdir -p "$INSTALL_DIR/models"
MODEL="$INSTALL_DIR/models/face_detection_yunet_2023mar.onnx"
if [ ! -f "$MODEL" ] || [ "$(stat -f%z "$MODEL")" -ne 232589 ]; then
  curl -L --fail \
    "https://media.githubusercontent.com/media/opencv/opencv_zoo/main/models/face_detection_yunet/face_detection_yunet_2023mar.onnx" \
    -o "$MODEL"
fi

AGENT_DIR="$HOME/Library/LaunchAgents"
AGENT_FILE="$AGENT_DIR/com.xg0ta.gotacreatorkit.plist"
mkdir -p "$AGENT_DIR"
cat > "$AGENT_FILE" <<PLIST
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>Label</key>
  <string>com.xg0ta.gotacreatorkit</string>
  <key>ProgramArguments</key>
  <array>
    <string>/bin/bash</string>
    <string>$INSTALL_DIR/Supervisor.sh</string>
  </array>
  <key>RunAtLoad</key>
  <true/>
  <key>KeepAlive</key>
  <true/>
  <key>StandardOutPath</key>
  <string>$INSTALL_DIR/supervisor.log</string>
  <key>StandardErrorPath</key>
  <string>$INSTALL_DIR/supervisor-error.log</string>
</dict>
</plist>
PLIST

launchctl bootstrap "gui/$UID" "$AGENT_FILE"
cp "$INSTALL_DIR/Gota Creator Kit.ccx" "$HOME/Downloads/Gota Creator Kit - Plugin.ccx"
open "$HOME/Downloads/Gota Creator Kit - Plugin.ccx"

echo
echo "Instalación terminada."
echo "Creative Cloud abrirá la confirmación del plugin."
echo "Puedes cerrar esta ventana."
read -r -p "Presiona Enter para finalizar..."
